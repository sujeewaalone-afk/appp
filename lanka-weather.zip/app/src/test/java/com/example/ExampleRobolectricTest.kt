package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Province
import com.example.data.model.SriLankaCities
import com.example.data.model.WeatherCodeTranslator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Lanka Weather", appName)
  }

  @Test
  fun `verify Sri Lanka cities data`() {
    val cities = SriLankaCities.allCities
    assertTrue("Should have over 20 Sri Lankan cities", cities.size >= 25)

    val colombo = cities.find { it.id == "colombo" }
    assertNotNull(colombo)
    assertEquals("කොළඹ", colombo?.nameSi)
    assertEquals(Province.WESTERN, colombo?.province)

    val nuwaraEliya = cities.find { it.id == "nuwara_eliya" }
    assertNotNull(nuwaraEliya)
    assertEquals("නුවරඑළිය", nuwaraEliya?.nameSi)

    val filtered = SriLankaCities.filterCities("මහනුවර")
    assertTrue(filtered.any { it.nameEn == "Kandy" })
  }

  @Test
  fun `verify WeatherCodeTranslator Sinhala mapping`() {
    val clear = WeatherCodeTranslator.getConditionSinhala(0)
    assertTrue(clear.contains("පැහැදිලි"))

    val rain = WeatherCodeTranslator.getConditionSinhala(61)
    assertTrue(rain.contains("වැසි"))

    val thunder = WeatherCodeTranslator.getConditionSinhala(95)
    assertTrue(thunder.contains("ගිගුරුම්"))
  }
}

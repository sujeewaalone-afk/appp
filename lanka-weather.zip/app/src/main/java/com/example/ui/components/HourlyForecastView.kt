package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.HourlyForecastItem

@Composable
fun HourlyForecastSection(
    hourlyItems: List<HourlyForecastItem>,
    modifier: Modifier = Modifier
) {
    if (hourlyItems.isEmpty()) return

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "පැයක කාලගුණ පුරෝකථනය",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Hourly",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.testTag("hourly_forecast_row")
        ) {
            items(hourlyItems) { item ->
                HourlyItemCard(item = item)
            }
        }
    }
}

@Composable
fun HourlyItemCard(
    item: HourlyForecastItem,
    modifier: Modifier = Modifier
) {
    val hasRain = item.rainfall > 0.1 || item.rainProbability > 30

    Card(
        modifier = modifier.width(96.dp),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (hasRain)
                Color(0xFFE1F5FE).copy(alpha = 0.8f)
            else
                MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Time
            Text(
                text = item.timeLabel,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Weather Icon
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            item.weatherCode >= 95 -> Color(0xFFEDE7F6)
                            item.weatherCode in 51..82 -> Color(0xFFE1F5FE)
                            item.weatherCode in 1..3 -> Color(0xFFECEFF1)
                            else -> Color(0xFFFFF8E1)
                        }
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = when {
                        item.weatherCode >= 95 -> Icons.Default.Thunderstorm
                        item.weatherCode in 51..82 -> Icons.Default.WaterDrop
                        item.weatherCode in 1..3 -> Icons.Default.Cloud
                        else -> Icons.Default.WbSunny
                    },
                    contentDescription = item.conditionSi,
                    modifier = Modifier.size(20.dp),
                    tint = when {
                        item.weatherCode >= 95 -> Color(0xFF5E35B1)
                        item.weatherCode in 51..82 -> Color(0xFF0288D1)
                        item.weatherCode in 1..3 -> Color(0xFF546E7A)
                        else -> Color(0xFFFFA000)
                    }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Temperature
            Text(
                text = "${String.format("%.0f", item.temperature)}°C",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Rain probability & amount
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.WaterDrop,
                    contentDescription = null,
                    tint = Color(0xFF0288D1),
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = "${item.rainProbability}%",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF0288D1)
                )
            }

            // Humidity
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Opacity,
                    contentDescription = null,
                    tint = Color(0xFF00897B),
                    modifier = Modifier.size(11.dp)
                )
                Text(
                    text = "${item.humidity}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF00897B)
                )
            }
        }
    }
}

package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CityWeather
import com.example.data.model.Province
import com.example.data.model.SriLankaCities
import com.example.data.model.SriLankaCity
import com.example.data.repository.WeatherRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface WeatherUiState {
    data object Loading : WeatherUiState
    data class Success(val weather: CityWeather) : WeatherUiState
    data class Error(val message: String, val cachedWeather: CityWeather?) : WeatherUiState
}

class WeatherViewModel(
    private val repository: WeatherRepository = WeatherRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow<WeatherUiState>(WeatherUiState.Loading)
    val uiState: StateFlow<WeatherUiState> = _uiState.asStateFlow()

    private val _selectedCity = MutableStateFlow<SriLankaCity>(SriLankaCities.defaultCity())
    val selectedCity: StateFlow<SriLankaCity> = _selectedCity.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedProvince = MutableStateFlow<Province?>(null)
    val selectedProvince: StateFlow<Province?> = _selectedProvince.asStateFlow()

    private val _filteredCities = MutableStateFlow<List<SriLankaCity>>(SriLankaCities.allCities)
    val filteredCities: StateFlow<List<SriLankaCity>> = _filteredCities.asStateFlow()

    private val _favoriteCityIds = MutableStateFlow<Set<String>>(
        setOf("colombo", "kandy", "galle", "nuwara_eliya", "jaffna")
    )
    val favoriteCityIds: StateFlow<Set<String>> = _favoriteCityIds.asStateFlow()

    private val _isCityPickerOpen = MutableStateFlow(false)
    val isCityPickerOpen: StateFlow<Boolean> = _isCityPickerOpen.asStateFlow()

    private val _isCompareOpen = MutableStateFlow(false)
    val isCompareOpen: StateFlow<Boolean> = _isCompareOpen.asStateFlow()

    private val _compareCity = MutableStateFlow<SriLankaCity?>(null)
    val compareCity: StateFlow<SriLankaCity?> = _compareCity.asStateFlow()

    private val _compareWeather = MutableStateFlow<CityWeather?>(null)
    val compareWeather: StateFlow<CityWeather?> = _compareWeather.asStateFlow()

    private val _isRefreshing = MutableStateFlow(false)
    val isRefreshing: StateFlow<Boolean> = _isRefreshing.asStateFlow()

    init {
        loadWeatherForCity(_selectedCity.value)
    }

    fun selectCity(city: SriLankaCity) {
        _selectedCity.value = city
        _isCityPickerOpen.value = false
        loadWeatherForCity(city)
    }

    fun refreshWeather() {
        val currentCity = _selectedCity.value
        _isRefreshing.value = true
        viewModelScope.launch {
            val result = repository.getWeatherForCity(currentCity, forceRefresh = true)
            result.onSuccess { weather ->
                _uiState.value = WeatherUiState.Success(weather)
            }.onFailure { err ->
                val prev = (_uiState.value as? WeatherUiState.Success)?.weather
                _uiState.value = WeatherUiState.Error(
                    message = err.message ?: "කාලගුණ දත්ත ලබා ගැනීමට නොහැකි විය",
                    cachedWeather = prev
                )
            }
            _isRefreshing.value = false
        }
    }

    private fun loadWeatherForCity(city: SriLankaCity) {
        _uiState.value = WeatherUiState.Loading
        viewModelScope.launch {
            val result = repository.getWeatherForCity(city, forceRefresh = false)
            result.onSuccess { weather ->
                _uiState.value = WeatherUiState.Success(weather)
            }.onFailure { err ->
                _uiState.value = WeatherUiState.Error(
                    message = err.message ?: "කාලගුණ දත්ත ලබා ගැනීමට නොහැකි විය",
                    cachedWeather = null
                )
            }
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        updateFilteredCities()
    }

    fun setProvinceFilter(province: Province?) {
        _selectedProvince.value = province
        updateFilteredCities()
    }

    private fun updateFilteredCities() {
        _filteredCities.value = SriLankaCities.filterCities(
            query = _searchQuery.value,
            province = _selectedProvince.value
        )
    }

    fun toggleFavorite(cityId: String) {
        val current = _favoriteCityIds.value.toMutableSet()
        if (current.contains(cityId)) {
            current.remove(cityId)
        } else {
            current.add(cityId)
        }
        _favoriteCityIds.value = current
    }

    fun openCityPicker() {
        _isCityPickerOpen.value = true
    }

    fun closeCityPicker() {
        _isCityPickerOpen.value = false
    }

    fun openCompareWith(secondaryCity: SriLankaCity) {
        _compareCity.value = secondaryCity
        _isCompareOpen.value = true
        viewModelScope.launch {
            val result = repository.getWeatherForCity(secondaryCity)
            result.onSuccess { weather ->
                _compareWeather.value = weather
            }
        }
    }

    fun closeCompare() {
        _isCompareOpen.value = false
        _compareCity.value = null
        _compareWeather.value = null
    }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Sky & Ocean Blues
val SkyBluePrimary = Color(0xFF0277BD) // Deep vibrant azure
val SkyBluePrimaryVariant = Color(0xFF01579B)
val TropicalCyan = Color(0xFF00ACC1) // Teal tropical lagoon
val GoldenSun = Color(0xFFFFB300) // Sunny golden yellow
val WarmSun = Color(0xFFFF8F00)

// Rain & Storm colors
val RainBlue = Color(0xFF1E88E5)
val RainCyan = Color(0xFF26C6DA)
val CloudGray = Color(0xFF78909C)

// Surface & Background (Light)
val WeatherBackgroundLight = Color(0xFFF4F9FD)
val WeatherSurfaceLight = Color(0xFFFFFFFF)
val WeatherSurfaceSubtleLight = Color(0xFFE8F1F8)

// Surface & Background (Dark)
val WeatherBackgroundDark = Color(0xFF0B141E)
val WeatherSurfaceDark = Color(0xFF132232)
val WeatherSurfaceSubtleDark = Color(0xFF1A2E44)

// Card Gradients
val OceanGradientStart = Color(0xFF0D47A1)
val OceanGradientEnd = Color(0xFF1976D2)

val SunnyGradientStart = Color(0xFFE65100)
val SunnyGradientEnd = Color(0xFFFFA000)

val RainyGradientStart = Color(0xFF1A237E)
val RainyGradientEnd = Color(0xFF3949AB)

val CoolGreenGradientStart = Color(0xFF004D40)
val CoolGreenGradientEnd = Color(0xFF00897B)

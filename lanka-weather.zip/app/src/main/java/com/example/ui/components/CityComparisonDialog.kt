package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Opacity
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CityWeather

@Composable
fun CityComparisonDialog(
    isOpen: Boolean,
    primaryWeather: CityWeather,
    compareWeather: CityWeather?,
    onDismiss: () -> Unit
) {
    if (!isOpen || compareWeather == null) return

    val p = primaryWeather
    val c = compareWeather

    val tempDiff = p.temperature - c.temperature
    val rainDiff = p.rainfall - c.rainfall
    val humDiff = p.humidity - c.humidity

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            Button(
                onClick = onDismiss,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("close_comparison_button")
            ) {
                Text("හරි (Close)")
            }
        },
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CompareArrows,
                        contentDescription = "Compare",
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "කාලගුණ දත්ත සංසන්දනය",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // City Names Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = p.city.nameSi,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Text(
                            text = p.city.province.sinhalaName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = "VS",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )

                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = c.city.nameSi,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        Text(
                            text = c.city.province.sinhalaName,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // 1. Temperature Comparison
                ComparisonMetricRow(
                    title = "උෂ්ණත්වය (Temperature)",
                    val1 = "${String.format("%.1f", p.temperature)}°C",
                    val2 = "${String.format("%.1f", c.temperature)}°C",
                    diffText = if (Math.abs(tempDiff) < 0.2) "සමාන උෂ්ණත්වයක්"
                    else if (tempDiff > 0) "${p.city.nameSi} ${String.format("%.1f", tempDiff)}°C කින් උණුසුම්ය"
                    else "${c.city.nameSi} ${String.format("%.1f", -tempDiff)}°C කින් උණුසුම්ය",
                    icon = Icons.Default.Thermostat,
                    tint = Color(0xFFE65100)
                )

                // 2. Rainfall Comparison
                ComparisonMetricRow(
                    title = "වර්ෂාපතනය (Rainfall)",
                    val1 = "${String.format("%.1f", p.rainfall)} mm",
                    val2 = "${String.format("%.1f", c.rainfall)} mm",
                    diffText = if (Math.abs(rainDiff) < 0.2) "සමාන වර්ෂාපතනයක්"
                    else if (rainDiff > 0) "${p.city.nameSi} වැඩි වැසි (${String.format("%.1f", rainDiff)} mm)"
                    else "${c.city.nameSi} වැඩි වැසි (${String.format("%.1f", -rainDiff)} mm)",
                    icon = Icons.Default.WaterDrop,
                    tint = Color(0xFF0288D1)
                )

                // 3. Humidity Comparison
                ComparisonMetricRow(
                    title = "ආර්ද්‍රතාවය (Humidity)",
                    val1 = "${p.humidity}%",
                    val2 = "${c.humidity}%",
                    diffText = if (humDiff == 0) "සමාන ආර්ද්‍රතාවයක්"
                    else if (humDiff > 0) "${p.city.nameSi} ආර්ද්‍රතාවය ${humDiff}% කින් ඉහළයි"
                    else "${c.city.nameSi} ආර්ද්‍රතාවය ${-humDiff}% කින් ඉහළයි",
                    icon = Icons.Default.Opacity,
                    tint = Color(0xFF00897B)
                )
            }
        }
    )
}

@Composable
private fun ComparisonMetricRow(
    title: String,
    val1: String,
    val2: String,
    diffText: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = tint,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = val1,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "•",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = val2,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = diffText,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.SemiBold,
                color = tint
            )
        }
    }
}

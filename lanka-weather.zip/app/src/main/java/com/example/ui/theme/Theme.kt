package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = TropicalCyan,
    onPrimary = Color.Black,
    primaryContainer = SkyBluePrimaryVariant,
    onPrimaryContainer = Color.White,
    secondary = GoldenSun,
    onSecondary = Color.Black,
    tertiary = RainCyan,
    background = WeatherBackgroundDark,
    surface = WeatherSurfaceDark,
    onBackground = Color.White,
    onSurface = Color.White,
    surfaceVariant = WeatherSurfaceSubtleDark,
    onSurfaceVariant = Color(0xFFCFD8DC)
)

private val LightColorScheme = lightColorScheme(
    primary = SkyBluePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE1F5FE),
    onPrimaryContainer = SkyBluePrimaryVariant,
    secondary = WarmSun,
    onSecondary = Color.White,
    tertiary = TropicalCyan,
    background = WeatherBackgroundLight,
    surface = WeatherSurfaceLight,
    onBackground = Color(0xFF0F172A),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = WeatherSurfaceSubtleLight,
    onSurfaceVariant = Color(0xFF455A64)
)

@Composable
fun LankaWeatherTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

package com.example.data.repository

import com.example.data.api.WeatherApiService
import com.example.data.model.CityWeather
import com.example.data.model.DailyForecastItem
import com.example.data.model.HourlyForecastItem
import com.example.data.model.OpenMeteoResponse
import com.example.data.model.SriLankaCity
import com.example.data.model.WeatherCodeTranslator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class WeatherRepository(
    private val apiService: WeatherApiService = WeatherApiService.create()
) {
    private val cache = mutableMapOf<String, CityWeather>()

    suspend fun getWeatherForCity(city: SriLankaCity, forceRefresh: Boolean = false): Result<CityWeather> =
        withContext(Dispatchers.IO) {
            if (!forceRefresh && cache.containsKey(city.id)) {
                return@withContext Result.success(cache.getValue(city.id))
            }

            try {
                val response = apiService.getForecast(
                    latitude = city.latitude,
                    longitude = city.longitude
                )
                val mapped = mapResponseToDomain(city, response, isLive = true)
                cache[city.id] = mapped
                Result.success(mapped)
            } catch (e: Exception) {
                // If network fails, return cached if present or fallback baseline
                val fallback = cache[city.id] ?: generateOfflineWeatherData(city)
                Result.success(fallback)
            }
        }

    private fun mapResponseToDomain(
        city: SriLankaCity,
        response: OpenMeteoResponse,
        isLive: Boolean
    ): CityWeather {
        val current = response.current
        val temp = current?.temperature ?: city.defaultTemp
        val rainfall = current?.precipitation ?: current?.rain ?: city.defaultRainfall
        val humidity = current?.relativeHumidity ?: city.defaultHumidity
        val apparent = current?.apparentTemperature ?: (temp + 2.5)
        val wind = current?.windSpeed ?: 12.0
        val pressure = current?.surfacePressure ?: 1012.0
        val weatherCode = current?.weatherCode ?: 1

        val conditionSi = WeatherCodeTranslator.getConditionSinhala(weatherCode)
        val conditionEn = WeatherCodeTranslator.getConditionEnglish(weatherCode)
        val rainStatusSi = WeatherCodeTranslator.getRainfallStatus(rainfall)
        val humidityStatusSi = WeatherCodeTranslator.getHumidityStatus(humidity)
        val adviceSi = WeatherCodeTranslator.generateAdvice(temp, rainfall, humidity, city)

        // Map hourly forecast
        val hourlyItems = mutableListOf<HourlyForecastItem>()
        val hourlyTimes = response.hourly?.time ?: emptyList()
        val hourlyTemps = response.hourly?.temperatures ?: emptyList()
        val hourlyHumidities = response.hourly?.relativeHumidities ?: emptyList()
        val hourlyPrecip = response.hourly?.precipitation ?: emptyList()
        val hourlyProb = response.hourly?.precipitationProbabilities ?: emptyList()
        val hourlyCodes = response.hourly?.weatherCodes ?: emptyList()

        val takeCount = minOf(24, hourlyTimes.size)
        for (i in 0 until takeCount) {
            val rawTime = hourlyTimes.getOrNull(i) ?: ""
            val timeLabel = formatHourlyTime(rawTime, i)
            val hTemp = hourlyTemps.getOrNull(i) ?: temp
            val hHum = hourlyHumidities.getOrNull(i) ?: humidity
            val hRain = hourlyPrecip.getOrNull(i) ?: 0.0
            val hProb = hourlyProb.getOrNull(i) ?: 10
            val hCode = hourlyCodes.getOrNull(i) ?: 1
            hourlyItems.add(
                HourlyForecastItem(
                    timeLabel = timeLabel,
                    temperature = hTemp,
                    humidity = hHum,
                    rainfall = hRain,
                    rainProbability = hProb,
                    weatherCode = hCode,
                    conditionSi = WeatherCodeTranslator.getConditionSinhala(hCode)
                )
            )
        }

        // Map daily forecast
        val dailyItems = mutableListOf<DailyForecastItem>()
        val dailyTimes = response.daily?.time ?: emptyList()
        val dailyCodes = response.daily?.weatherCodes ?: emptyList()
        val dailyMaxTemps = response.daily?.maxTemperatures ?: emptyList()
        val dailyMinTemps = response.daily?.minTemperatures ?: emptyList()
        val dailyPrecipSums = response.daily?.precipitationSums ?: emptyList()
        val dailyProbMax = response.daily?.precipitationProbabilitiesMax ?: emptyList()

        val daysCount = minOf(7, dailyTimes.size)
        for (i in 0 until daysCount) {
            val rawDate = dailyTimes.getOrNull(i) ?: ""
            val dayLabelSi = getSinhalaDayOfWeek(rawDate, i)
            val dCode = dailyCodes.getOrNull(i) ?: weatherCode
            val dMax = dailyMaxTemps.getOrNull(i) ?: (temp + 2.0)
            val dMin = dailyMinTemps.getOrNull(i) ?: (temp - 3.0)
            val dRain = dailyPrecipSums.getOrNull(i) ?: rainfall
            val dProb = dailyProbMax.getOrNull(i) ?: 30

            dailyItems.add(
                DailyForecastItem(
                    dayLabelSi = dayLabelSi,
                    dateLabel = formatDateLabel(rawDate),
                    minTemp = dMin,
                    maxTemp = dMax,
                    rainSum = dRain,
                    rainProbability = dProb,
                    weatherCode = dCode,
                    conditionSi = WeatherCodeTranslator.getConditionSinhala(dCode)
                )
            )
        }

        val currentTimeStr = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())

        return CityWeather(
            city = city,
            temperature = temp,
            rainfall = rainfall,
            humidity = humidity,
            apparentTemperature = apparent,
            windSpeed = wind,
            pressure = pressure,
            weatherCode = weatherCode,
            conditionSi = conditionSi,
            conditionEn = conditionEn,
            rainStatusSi = rainStatusSi,
            humidityStatusSi = humidityStatusSi,
            adviceSi = adviceSi,
            hourly = hourlyItems.ifEmpty { generateOfflineHourly(temp, humidity) },
            daily = dailyItems.ifEmpty { generateOfflineDaily(temp) },
            isLive = isLive,
            lastUpdatedTime = currentTimeStr
        )
    }

    private fun generateOfflineWeatherData(city: SriLankaCity): CityWeather {
        val temp = city.defaultTemp
        val rainfall = city.defaultRainfall
        val humidity = city.defaultHumidity
        val weatherCode = if (rainfall > 3.0) 61 else 1
        val conditionSi = WeatherCodeTranslator.getConditionSinhala(weatherCode)
        val conditionEn = WeatherCodeTranslator.getConditionEnglish(weatherCode)

        return CityWeather(
            city = city,
            temperature = temp,
            rainfall = rainfall,
            humidity = humidity,
            apparentTemperature = temp + 2.0,
            windSpeed = 11.5,
            pressure = 1012.0,
            weatherCode = weatherCode,
            conditionSi = conditionSi,
            conditionEn = conditionEn,
            rainStatusSi = WeatherCodeTranslator.getRainfallStatus(rainfall),
            humidityStatusSi = WeatherCodeTranslator.getHumidityStatus(humidity),
            adviceSi = WeatherCodeTranslator.generateAdvice(temp, rainfall, humidity, city),
            hourly = generateOfflineHourly(temp, humidity),
            daily = generateOfflineDaily(temp),
            isLive = false,
            lastUpdatedTime = "නොබැඳි දත්ත (Offline)"
        )
    }

    private fun generateOfflineHourly(baseTemp: Double, baseHumidity: Int): List<HourlyForecastItem> {
        val items = mutableListOf<HourlyForecastItem>()
        val hours = listOf("06:00", "09:00", "12:00", "15:00", "18:00", "21:00", "00:00", "03:00")
        val offsets = listOf(-2.0, 0.5, 2.5, 2.0, -0.5, -1.8, -2.5, -3.0)
        for (i in hours.indices) {
            val t = baseTemp + offsets[i]
            items.add(
                HourlyForecastItem(
                    timeLabel = hours[i],
                    temperature = Math.round(t * 10.0) / 10.0,
                    humidity = (baseHumidity + (offsets[i] * -2).toInt()).coerceIn(40, 95),
                    rainfall = if (i in 3..5) 1.2 else 0.0,
                    rainProbability = if (i in 3..5) 45 else 15,
                    weatherCode = if (i in 3..5) 61 else 1,
                    conditionSi = if (i in 3..5) "සැහැල්ලු වැසි" else "පැහැදිලි අහස"
                )
            )
        }
        return items
    }

    private fun generateOfflineDaily(baseTemp: Double): List<DailyForecastItem> {
        val days = listOf("අද", "හෙට", "බදාදා", "බ්‍රහස්පතින්දා", "සිකුරාදා", "සෙනසුරාදා", "ඉරිදා")
        return days.mapIndexed { index, name ->
            DailyForecastItem(
                dayLabelSi = name,
                dateLabel = "දින ${index + 1}",
                minTemp = Math.round((baseTemp - 3.5) * 10.0) / 10.0,
                maxTemp = Math.round((baseTemp + 2.0) * 10.0) / 10.0,
                rainSum = if (index % 2 == 0) 3.5 else 0.5,
                rainProbability = if (index % 2 == 0) 50 else 20,
                weatherCode = if (index % 2 == 0) 61 else 2,
                conditionSi = if (index % 2 == 0) "වැසි සහිත" else "අර්ධ වළාකුළු"
            )
        }
    }

    private fun formatHourlyTime(raw: String, index: Int): String {
        return try {
            if (raw.contains("T")) {
                val parts = raw.split("T")
                if (parts.size > 1) parts[1].substring(0, 5) else "${index}:00"
            } else {
                "${index}:00"
            }
        } catch (e: Exception) {
            "${index}:00"
        }
    }

    private fun formatDateLabel(raw: String): String {
        return try {
            if (raw.contains("-")) {
                val parts = raw.split("-")
                if (parts.size >= 3) "${parts[2]}/${parts[1]}" else raw
            } else raw
        } catch (e: Exception) {
            raw
        }
    }

    private fun getSinhalaDayOfWeek(rawDate: String, dayIndex: Int): String {
        if (dayIndex == 0) return "අද (Today)"
        if (dayIndex == 1) return "හෙට (Tomorrow)"

        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdf.parse(rawDate)
            if (date != null) {
                val cal = Calendar.getInstance().apply { time = date }
                when (cal.get(Calendar.DAY_OF_WEEK)) {
                    Calendar.SUNDAY -> "ඉරිදා"
                    Calendar.MONDAY -> "සඳුදා"
                    Calendar.TUESDAY -> "අඟහරුවාදා"
                    Calendar.WEDNESDAY -> "බදාදා"
                    Calendar.THURSDAY -> "බ්‍රහස්පතින්දා"
                    Calendar.FRIDAY -> "සිකුරාදා"
                    Calendar.SATURDAY -> "සෙනසුරාදා"
                    else -> "දින ${dayIndex + 1}"
                }
            } else {
                "දින ${dayIndex + 1}"
            }
        } catch (e: Exception) {
            "දින ${dayIndex + 1}"
        }
    }
}

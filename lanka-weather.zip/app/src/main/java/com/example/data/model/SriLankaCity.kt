package com.example.data.model

enum class Province(
    val englishName: String,
    val sinhalaName: String
) {
    WESTERN("Western Province", "බස්නාහිර පළාත"),
    CENTRAL("Central Province", "මධ්‍යම පළාත"),
    SOUTHERN("Southern Province", "දකුණු පළාත"),
    NORTHERN("Northern Province", "උතුරු පළාත"),
    EASTERN("Eastern Province", "නැගෙනහිර පළාත"),
    NORTH_WESTERN("North Western Province", "වයඹ පළාත"),
    NORTH_CENTRAL("North Central Province", "උතුරු මැද පළාත"),
    UVA("Uva Province", "ඌව පළාත"),
    SABARAGAMUWA("Sabaragamuwa Province", "සබරගමුව පළාත")
}

data class SriLankaCity(
    val id: String,
    val nameEn: String,
    val nameSi: String,
    val province: Province,
    val latitude: Double,
    val longitude: Double,
    val elevationMeters: Int,
    val descriptionSi: String,
    val defaultTemp: Double,
    val defaultRainfall: Double,
    val defaultHumidity: Int
)

object SriLankaCities {
    val allCities: List<SriLankaCity> = listOf(
        SriLankaCity(
            id = "colombo",
            nameEn = "Colombo",
            nameSi = "කොළඹ",
            province = Province.WESTERN,
            latitude = 6.9271,
            longitude = 79.8612,
            elevationMeters = 7,
            descriptionSi = "ශ්‍රී ලංකාවේ ප්‍රධාන වාණිජ අගනගරය හා වරාය නගරය",
            defaultTemp = 30.5,
            defaultRainfall = 4.2,
            defaultHumidity = 78
        ),
        SriLankaCity(
            id = "kandy",
            nameEn = "Kandy",
            nameSi = "මහනුවර",
            province = Province.CENTRAL,
            latitude = 7.2906,
            longitude = 80.6337,
            elevationMeters = 500,
            descriptionSi = "ශ්‍රී දළදා සමිඳුන් වැඩවසන ඓතිහාසික කඳුකර අගනගරය",
            defaultTemp = 25.0,
            defaultRainfall = 2.8,
            defaultHumidity = 74
        ),
        SriLankaCity(
            id = "galle",
            nameEn = "Galle",
            nameSi = "ගාල්ල",
            province = Province.SOUTHERN,
            latitude = 6.0535,
            longitude = 80.2210,
            elevationMeters = 13,
            descriptionSi = "ලෝක උරුම ලන්දේසි බලකොටුව පිහිටි දකුණේ ප්‍රධාන නගරය",
            defaultTemp = 28.5,
            defaultRainfall = 3.5,
            defaultHumidity = 82
        ),
        SriLankaCity(
            id = "jaffna",
            nameEn = "Jaffna",
            nameSi = "යාපනය",
            province = Province.NORTHERN,
            latitude = 9.6615,
            longitude = 80.0255,
            elevationMeters = 5,
            descriptionSi = "සංස්කෘතික හා ඓතිහාසික උරුමයන්ගෙන් පොහොසත් උතුරේ අගනගරය",
            defaultTemp = 31.8,
            defaultRainfall = 0.5,
            defaultHumidity = 70
        ),
        SriLankaCity(
            id = "nuwara_eliya",
            nameEn = "Nuwara Eliya",
            nameSi = "නුවරඑළිය",
            province = Province.CENTRAL,
            latitude = 6.9497,
            longitude = 80.7891,
            elevationMeters = 1868,
            descriptionSi = "සුන්දර තේ වතු හා මීදුම් සළු සහිත සිසිල් කඳුකර නගරය",
            defaultTemp = 16.2,
            defaultRainfall = 5.6,
            defaultHumidity = 88
        ),
        SriLankaCity(
            id = "anuradhapura",
            nameEn = "Anuradhapura",
            nameSi = "අනුරාධපුරය",
            province = Province.NORTH_CENTRAL,
            latitude = 8.3114,
            longitude = 80.4037,
            elevationMeters = 81,
            descriptionSi = "ශ්‍රී මහා බෝධීන් වහන්සේ සහ රුවන්වැලි සෑය පිහිටි පූජනීය නගරය",
            defaultTemp = 32.4,
            defaultRainfall = 1.0,
            defaultHumidity = 65
        ),
        SriLankaCity(
            id = "trincomalee",
            nameEn = "Trincomalee",
            nameSi = "ත්‍රිකුණාමලය",
            province = Province.EASTERN,
            latitude = 8.5874,
            longitude = 81.2152,
            elevationMeters = 8,
            descriptionSi = "සුප්‍රසිද්ධ ස්වභාවික වරාය හා නිලාවේලි වෙරළ පිහිටි නගරය",
            defaultTemp = 32.0,
            defaultRainfall = 1.2,
            defaultHumidity = 68
        ),
        SriLankaCity(
            id = "batticaloa",
            nameEn = "Batticaloa",
            nameSi = "මඩකලපුව",
            province = Province.EASTERN,
            latitude = 7.7310,
            longitude = 81.6747,
            elevationMeters = 6,
            descriptionSi = "ගායනා කරන මසුන් සහ සුන්දර කලපු දූපත් සහිත නැගෙනහිර නගරය",
            defaultTemp = 31.2,
            defaultRainfall = 1.8,
            defaultHumidity = 72
        ),
        SriLankaCity(
            id = "badulla",
            nameEn = "Badulla",
            nameSi = "බදුල්ල",
            province = Province.UVA,
            latitude = 6.9895,
            longitude = 81.0557,
            elevationMeters = 680,
            descriptionSi = "මුතියංගණ රජමහා විහාරය සහ දුන්හිඳ දියඇල්ල පිහිටි ඌව අගනගරය",
            defaultTemp = 24.5,
            defaultRainfall = 3.0,
            defaultHumidity = 76
        ),
        SriLankaCity(
            id = "ratnapura",
            nameEn = "Ratnapura",
            nameSi = "රත්නපුර",
            province = Province.SABARAGAMUWA,
            latitude = 6.6828,
            longitude = 80.3992,
            elevationMeters = 21,
            descriptionSi = "මැණික් කර්මාන්තයට හා සමනල කඳු පිවිසුමට ප්‍රසිද්ධ නගරය",
            defaultTemp = 27.8,
            defaultRainfall = 8.4,
            defaultHumidity = 86
        ),
        SriLankaCity(
            id = "kurunegala",
            nameEn = "Kurunegala",
            nameSi = "කුරුණෑගල",
            province = Province.NORTH_WESTERN,
            latitude = 7.4863,
            longitude = 80.3623,
            elevationMeters = 116,
            descriptionSi = "ඇතුගල්පුරවරය ලෙස ප්‍රකට වයඹ පළාතේ ප්‍රධාන නගරය",
            defaultTemp = 31.0,
            defaultRainfall = 2.1,
            defaultHumidity = 73
        ),
        SriLankaCity(
            id = "matara",
            nameEn = "Matara",
            nameSi = "මාතර",
            province = Province.SOUTHERN,
            latitude = 5.9549,
            longitude = 80.5550,
            elevationMeters = 15,
            descriptionSi = "නිල්වලා ගං තීරයේ පිහිටි දකුණු ලක ඓතිහාසික නගරය",
            defaultTemp = 29.2,
            defaultRainfall = 3.8,
            defaultHumidity = 80
        ),
        SriLankaCity(
            id = "negombo",
            nameEn = "Negombo",
            nameSi = "මීගමුව",
            province = Province.WESTERN,
            latitude = 7.2008,
            longitude = 79.8736,
            elevationMeters = 2,
            descriptionSi = "ධීවර කර්මාන්තය හා සංචාරක වෙරළ තීරයන් සහිත නගරය",
            defaultTemp = 30.1,
            defaultRainfall = 3.9,
            defaultHumidity = 79
        ),
        SriLankaCity(
            id = "gampaha",
            nameEn = "Gampaha",
            nameSi = "ගම්පහ",
            province = Province.WESTERN,
            latitude = 7.0840,
            longitude = 79.9939,
            elevationMeters = 15,
            descriptionSi = "පළමු රබර් ගස රෝපණය කළ හෙනරත්ගොඩ උද්භිද උද්‍යානය සහිත නගරය",
            defaultTemp = 30.0,
            defaultRainfall = 4.0,
            defaultHumidity = 79
        ),
        SriLankaCity(
            id = "kalutara",
            nameEn = "Kalutara",
            nameSi = "කළුතර",
            province = Province.WESTERN,
            latitude = 6.5854,
            longitude = 79.9607,
            elevationMeters = 10,
            descriptionSi = "ප්‍රසිද්ධ කළුතර බෝධිය සහ කළු ගං මෝය පිහිටි නගරය",
            defaultTemp = 29.6,
            defaultRainfall = 4.5,
            defaultHumidity = 81
        ),
        SriLankaCity(
            id = "hambantota",
            nameEn = "Hambantota",
            nameSi = "හම්බන්තොට",
            province = Province.SOUTHERN,
            latitude = 6.1248,
            longitude = 81.1185,
            elevationMeters = 16,
            descriptionSi = "ලුණු ලේවායන් සහ ජාත්‍යන්තර වරාය සහිත ශුෂ්ක කලාපීය නගරය",
            defaultTemp = 31.5,
            defaultRainfall = 0.8,
            defaultHumidity = 69
        ),
        SriLankaCity(
            id = "polonnaruwa",
            nameEn = "Polonnaruwa",
            nameSi = "පොළොන්නරුව",
            province = Province.NORTH_CENTRAL,
            latitude = 7.9403,
            longitude = 81.0188,
            elevationMeters = 59,
            descriptionSi = "පරාක්‍රම සමුද්‍රය හා ගල් විහාරය පිහිටි මධ්‍යකාලීන අගනගරය",
            defaultTemp = 32.2,
            defaultRainfall = 1.3,
            defaultHumidity = 67
        ),
        SriLankaCity(
            id = "matale",
            nameEn = "Matale",
            nameSi = "මාතලේ",
            province = Province.CENTRAL,
            latitude = 7.4675,
            longitude = 80.6234,
            elevationMeters = 364,
            descriptionSi = "කුළුබඩු වතු සහ අලුවිහාරය පිහිටි කඳුකර මධ්‍යම නගරය",
            defaultTemp = 26.8,
            defaultRainfall = 2.6,
            defaultHumidity = 75
        ),
        SriLankaCity(
            id = "bandarawela",
            nameEn = "Bandarawela",
            nameSi = "බණ්ඩාරවෙල",
            province = Province.UVA,
            latitude = 6.8333,
            longitude = 80.9833,
            elevationMeters = 1225,
            descriptionSi = "සුවදායී සෞම්‍ය දේශගුණයක් සහිත උසස් කඳුකර නගරය",
            defaultTemp = 21.0,
            defaultRainfall = 3.2,
            defaultHumidity = 78
        ),
        SriLankaCity(
            id = "ella",
            nameEn = "Ella",
            nameSi = "ඇල්ල",
            province = Province.UVA,
            latitude = 6.8667,
            longitude = 81.0466,
            elevationMeters = 1041,
            descriptionSi = "නව ආරුක්කු පාලම හා සුන්දර ඇල්ල කපොල්ල සහිත සංචාරක පාරාදීසය",
            defaultTemp = 21.8,
            defaultRainfall = 3.6,
            defaultHumidity = 80
        ),
        SriLankaCity(
            id = "kegalle",
            nameEn = "Kegalle",
            nameSi = "කෑගල්ල",
            province = Province.SABARAGAMUWA,
            latitude = 7.2514,
            longitude = 80.3464,
            elevationMeters = 175,
            descriptionSi = "පින්නවල අලි අනාථාගාරය ආසන්නයේ පිහිටි සබරගමු නගරය",
            defaultTemp = 28.2,
            defaultRainfall = 5.2,
            defaultHumidity = 82
        ),
        SriLankaCity(
            id = "puttalam",
            nameEn = "Puttalam",
            nameSi = "පුත්තලම",
            province = Province.NORTH_WESTERN,
            latitude = 8.0362,
            longitude = 79.8283,
            elevationMeters = 8,
            descriptionSi = "පුත්තලම කලපුව, සුළං විදුලි බලාගාර සහ ලුණු කර්මාන්තය සහිත නගරය",
            defaultTemp = 31.6,
            defaultRainfall = 1.1,
            defaultHumidity = 71
        ),
        SriLankaCity(
            id = "vavuniya",
            nameEn = "Vavuniya",
            nameSi = "වවුනියාව",
            province = Province.NORTHERN,
            latitude = 8.7514,
            longitude = 80.4971,
            elevationMeters = 98,
            descriptionSi = "උතුරු පළාතට පිවිසෙන ප්‍රධාන දොරටුව වන නගරය",
            defaultTemp = 32.0,
            defaultRainfall = 0.9,
            defaultHumidity = 66
        ),
        SriLankaCity(
            id = "monaragala",
            nameEn = "Monaragala",
            nameSi = "මොණරාගල",
            province = Province.UVA,
            latitude = 6.8728,
            longitude = 81.3507,
            elevationMeters = 200,
            descriptionSi = "රබර් සහ උක් වගාවන්ගෙන් සමන්විත ඌව පළාතේ නගරය",
            defaultTemp = 29.8,
            defaultRainfall = 2.4,
            defaultHumidity = 73
        ),
        SriLankaCity(
            id = "dambulla",
            nameEn = "Dambulla",
            nameSi = "දඹුල්ල",
            province = Province.CENTRAL,
            latitude = 7.8600,
            longitude = 80.6517,
            elevationMeters = 158,
            descriptionSi = "රන්ගිරි දඹුලු ලෙන් විහාරය සහ ආර්ථික මධ්‍යස්ථානය පිහිටි නගරය",
            defaultTemp = 30.8,
            defaultRainfall = 1.6,
            defaultHumidity = 70
        ),
        SriLankaCity(
            id = "mannar",
            nameEn = "Mannar",
            nameSi = "මන්නාරම",
            province = Province.NORTHERN,
            latitude = 8.9810,
            longitude = 79.9044,
            elevationMeters = 6,
            descriptionSi = "ඓතිහාසික තිරුකේතීශ්වරම් කෝවිල හා බයෝබැබ් ගස් සහිත වෙරළබඩ නගරය",
            defaultTemp = 31.4,
            defaultRainfall = 0.6,
            defaultHumidity = 72
        ),
        SriLankaCity(
            id = "kilinochchi",
            nameEn = "Kilinochchi",
            nameSi = "කිලිනොච්චිය",
            province = Province.NORTHERN,
            latitude = 9.3803,
            longitude = 80.3992,
            elevationMeters = 30,
            descriptionSi = "ඉරණමඩු ජලාශය ආශ්‍රිත කෘෂිකාර්මික උතුරු නගරය",
            defaultTemp = 31.9,
            defaultRainfall = 0.7,
            defaultHumidity = 69
        ),
        SriLankaCity(
            id = "mullaitivu",
            nameEn = "Mullaitivu",
            nameSi = "මුලතිව්",
            province = Province.NORTHERN,
            latitude = 9.2671,
            longitude = 80.8142,
            elevationMeters = 7,
            descriptionSi = "නන්දිකඩාල් කලපුව ආශ්‍රිත ඊසානදිග වෙරළබඩ නගරය",
            defaultTemp = 31.5,
            defaultRainfall = 1.1,
            defaultHumidity = 71
        ),
        SriLankaCity(
            id = "ampara",
            nameEn = "Ampara",
            nameSi = "අම්පාර",
            province = Province.EASTERN,
            latitude = 7.2975,
            longitude = 81.6747,
            elevationMeters = 44,
            descriptionSi = "සේනානායක සමුද්‍රය පිහිටි දිගාමඩුලු නැගෙනහිර නගරය",
            defaultTemp = 31.7,
            defaultRainfall = 1.4,
            defaultHumidity = 70
        ),
        SriLankaCity(
            id = "tangalle",
            nameEn = "Tangalle",
            nameSi = "තංගල්ල",
            province = Province.SOUTHERN,
            latitude = 6.0243,
            longitude = 80.7941,
            elevationMeters = 10,
            descriptionSi = "සුන්දර මුහුදු තීරය හා හුම්මානය ස්වභාවික විස්මය සහිත නගරය",
            defaultTemp = 29.8,
            defaultRainfall = 2.7,
            defaultHumidity = 79
        ),
        SriLankaCity(
            id = "hatton",
            nameEn = "Hatton",
            nameSi = "හැටන්",
            province = Province.CENTRAL,
            latitude = 6.8916,
            longitude = 80.5966,
            elevationMeters = 1271,
            descriptionSi = "ශ්‍රී පාදස්ථාන වන්දනා පිවිසුම සහ තේ වගාවන්ට ප්‍රකට කඳුකර නගරය",
            defaultTemp = 19.5,
            defaultRainfall = 6.2,
            defaultHumidity = 85
        )
    )

    fun defaultCity(): SriLankaCity = allCities.first { it.id == "colombo" }

    fun findCityById(id: String): SriLankaCity =
        allCities.find { it.id == id } ?: defaultCity()

    fun filterCities(query: String, province: Province? = null): List<SriLankaCity> {
        val q = query.trim().lowercase()
        return allCities.filter { city ->
            val matchesProvince = province == null || city.province == province
            val matchesQuery = q.isEmpty() ||
                city.nameEn.lowercase().contains(q) ||
                city.nameSi.contains(q) ||
                city.descriptionSi.contains(q) ||
                city.province.englishName.lowercase().contains(q) ||
                city.province.sinhalaName.contains(q)
            matchesProvince && matchesQuery
        }
    }
}

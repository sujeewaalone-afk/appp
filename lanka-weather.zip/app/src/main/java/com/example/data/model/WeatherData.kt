package com.example.data.model

data class HourlyForecastItem(
    val timeLabel: String,
    val temperature: Double,
    val humidity: Int,
    val rainfall: Double,
    val rainProbability: Int,
    val weatherCode: Int,
    val conditionSi: String
)

data class DailyForecastItem(
    val dayLabelSi: String,
    val dateLabel: String,
    val minTemp: Double,
    val maxTemp: Double,
    val rainSum: Double,
    val rainProbability: Int,
    val weatherCode: Int,
    val conditionSi: String
)

data class CityWeather(
    val city: SriLankaCity,
    val temperature: Double,
    val rainfall: Double,
    val humidity: Int,
    val apparentTemperature: Double,
    val windSpeed: Double,
    val pressure: Double,
    val weatherCode: Int,
    val conditionSi: String,
    val conditionEn: String,
    val rainStatusSi: String,
    val humidityStatusSi: String,
    val adviceSi: String,
    val hourly: List<HourlyForecastItem>,
    val daily: List<DailyForecastItem>,
    val isLive: Boolean,
    val lastUpdatedTime: String
)

object WeatherCodeTranslator {
    fun getConditionSinhala(code: Int): String {
        return when (code) {
            0 -> "පැහැදිලි හිරු එළිය"
            1 -> "ප්‍රධාන වශයෙන් පැහැදිලි"
            2 -> "අර්ධ වශයෙන් වළාකුළු"
            3 -> "වළාකුළු බර අහස"
            45, 48 -> "මීදුම් තත්ත්වය"
            51, 53, 55 -> "සිහින් පොද වැසි"
            61 -> "සැහැල්ලු වැසි"
            63 -> "මධ්‍යස්ථ වැසි"
            65 -> "තද ධාරානිපාත වැසි"
            80 -> "මඳ වැසි රළ"
            81 -> "තද වැසි රළ"
            82 -> "අධික වැසි කුණාටු"
            95 -> "ගිගුරුම් සහිත තද වැසි"
            96, 99 -> "අකුණු සහ ගිගුරුම් සහිත වැසි"
            else -> "සාමාන්‍ය කාලගුණය"
        }
    }

    fun getConditionEnglish(code: Int): String {
        return when (code) {
            0 -> "Clear Sky"
            1 -> "Mainly Clear"
            2 -> "Partly Cloudy"
            3 -> "Overcast"
            45, 48 -> "Foggy / Mist"
            51, 53, 55 -> "Drizzle"
            61 -> "Light Rain"
            63 -> "Moderate Rain"
            65 -> "Heavy Rain"
            80 -> "Light Showers"
            81 -> "Heavy Showers"
            82 -> "Violent Rain"
            95 -> "Thunderstorm"
            96, 99 -> "Severe Thunderstorm"
            else -> "Scattered Weather"
        }
    }

    fun getRainfallStatus(rainfall: Double): String {
        return when {
            rainfall <= 0.05 -> "වැසි නැත (වියළි)"
            rainfall < 2.5 -> "සැහැල්ලු පොද වැසි"
            rainfall < 10.0 -> "මධ්‍යස්ථ වැසි"
            rainfall < 30.0 -> "තද වැසි"
            else -> "අධික ධාරානිපාත වැසි"
        }
    }

    fun getHumidityStatus(humidity: Int): String {
        return when {
            humidity < 50 -> "වියළි වාතාවරණයක්"
            humidity in 50..69 -> "සුවපහසු ආර්ද්‍රතාවය"
            humidity in 70..84 -> "ඉහළ ආර්ද්‍රතාවය (තෙතමනය)"
            else -> "අධික ආර්ද්‍රතාවය (අතිශය තෙත්)"
        }
    }

    fun generateAdvice(temp: Double, rainfall: Double, humidity: Int, city: SriLankaCity): String {
        return when {
            rainfall > 15.0 -> "⚠️ ${city.nameSi} ප්‍රදේශයේ අධික වැසි සහිතයි. කුඩයක් හෝ වැහි කබායක් රැගෙන යන්න. ගමනාගමනයේදී විමසිලිමත් වන්න."
            rainfall > 2.0 -> "🌧️ මධ්‍යස්ථ වැසි අපේක්ෂා කෙරේ. එළිමහන් කටයුතුවලදී සැලකිලිමත් වන්න."
            temp >= 33.0 -> "☀️ අධික උෂ්ණත්වයක් පවතී (${temp}°C). ප්‍රමාණවත් තරම් ජලය පානය කරන්න සහ සෘජු හිරු එළියෙන් වළකින්න."
            temp <= 18.0 -> "🧥 සිසිල් කාලගුණයක් පවතී (${temp}°C). උණුසුම් ඇඳුම් ඇඳීම සුදුසුය."
            humidity >= 85 -> "💧 වායුගෝලයේ අධික තෙතමනයක් (${humidity}%) පවතින බැවින් දහඩිය දැමීම වැඩි විය හැක."
            else -> "🌿 ${city.nameSi} ප්‍රදේශයේ ඉතා ප්‍රසන්න සහ සුවදායක කාලගුණික වාතාවරණයක් පවතී."
        }
    }
}

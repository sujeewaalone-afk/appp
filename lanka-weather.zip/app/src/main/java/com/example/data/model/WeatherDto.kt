package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class OpenMeteoResponse(
    val latitude: Double? = null,
    val longitude: Double? = null,
    val current: CurrentWeatherDto? = null,
    val hourly: HourlyWeatherDto? = null,
    val daily: DailyWeatherDto? = null
)

@JsonClass(generateAdapter = true)
data class CurrentWeatherDto(
    val time: String? = null,
    @Json(name = "temperature_2m") val temperature: Double? = null,
    @Json(name = "relative_humidity_2m") val relativeHumidity: Int? = null,
    @Json(name = "apparent_temperature") val apparentTemperature: Double? = null,
    val precipitation: Double? = null,
    val rain: Double? = null,
    @Json(name = "weather_code") val weatherCode: Int? = null,
    @Json(name = "wind_speed_10m") val windSpeed: Double? = null,
    @Json(name = "surface_pressure") val surfacePressure: Double? = null
)

@JsonClass(generateAdapter = true)
data class HourlyWeatherDto(
    val time: List<String>? = null,
    @Json(name = "temperature_2m") val temperatures: List<Double>? = null,
    @Json(name = "relative_humidity_2m") val relativeHumidities: List<Int>? = null,
    @Json(name = "precipitation_probability") val precipitationProbabilities: List<Int>? = null,
    val precipitation: List<Double>? = null,
    @Json(name = "weather_code") val weatherCodes: List<Int>? = null
)

@JsonClass(generateAdapter = true)
data class DailyWeatherDto(
    val time: List<String>? = null,
    @Json(name = "weather_code") val weatherCodes: List<Int>? = null,
    @Json(name = "temperature_2m_max") val maxTemperatures: List<Double>? = null,
    @Json(name = "temperature_2m_min") val minTemperatures: List<Double>? = null,
    @Json(name = "precipitation_sum") val precipitationSums: List<Double>? = null,
    @Json(name = "precipitation_probability_max") val precipitationProbabilitiesMax: List<Int>? = null
)
